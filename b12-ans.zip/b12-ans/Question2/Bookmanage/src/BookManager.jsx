import React, { useState } from 'react';

const BookManager = () => {
    const [bookId, setBookId] = useState('');
    const [bookName, setBookName] = useState('');
    const [author, setAuthor] = useState('');
    const [price, setPrice] = useState('');
    const [books, setBooks] = useState([]);

    const handleAddBook = () => {
        if (bookId && bookName && author && price) {
            setBooks([...books, { bookId, bookName, author, price }]);
            setBookId('');
            setBookName('');
            setAuthor('');
            setPrice('');
        } else {
            alert('Please fill in all fields.');
        }
    };

    const handleDeleteBook = (id) => {
        setBooks(books.filter(book => book.bookId !== id));
    };

    return (
        <div>
            <h1>Book Management</h1>
            <form>
                <div>
                    <label>Book ID:</label>
                    <input
                        type="text"
                        value={bookId}
                        onChange={(e) => setBookId(e.target.value)}
                    />
                </div>
                <br></br>
                <br></br>
                <div>
                    <label>Book Name:</label>
                    <input
                        type="text"
                        value={bookName}
                        onChange={(e) => setBookName(e.target.value)}
                    />
                </div>
                <br></br>
                <br></br>
                <div>
                    <label>Author:</label>
                    <input
                        type="text"
                        value={author}
                        onChange={(e) => setAuthor(e.target.value)}
                    />
                </div>
                <br></br>
                <br></br>
                <div>
                    <label>Price:</label>
                    <input
                        type="text"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                    />
                </div>
                <br></br>
                <br></br>
                <button type="button" onClick={handleAddBook}>Add Book</button>
            </form>
            <br></br>
            <br></br>
            <h2>List of Books</h2>
            <ul>
                {books.map(book => (
                    <li key={book.bookId}>
                        {`${book.bookName} by ${book.author} - ₹${book.price}`}
                        <button onClick={() => handleDeleteBook(book.bookId)}>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default BookManager;
